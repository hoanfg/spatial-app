# Kiểm chứng độc lập Local Moran / LISA — Diên Khánh, Bắc Kinh (2020, 500 m)

**Ngày:** 11/11/2026. **Nguồn:** `CHN_beijing_yanqing_2020_500m_lisa_cells.csv` do người dùng xuất từ spatial-app. **Công thức đối chiếu:** repository `hoanfg/spatial-app`, `main` sau PR #10, commit `9574cf872c52d266aa15c363df7965cce31601f0`. Đây là phân tích độc lập trên bản CSV đã xuất, **không phải** một phép đo lặp lại từ raster VIIRS gốc hay một phiên chạy ESDA.

## Kiểm chứng xác định (deterministic)

| Phép kiểm | Kết quả |
|---|---|
| Số dòng / ô | 8.333 |
| Ô biên theo ngưỡng diện tích < 0,99 × 0,25 km² | 600; khớp hoàn toàn |
| Ô tham gia LISA | 7.733 |
| Ma trận láng giềng Queen, so số láng giềng từng ô | 8.333/8.333 khớp |
| Quadrant thô HH, LL, HL, LH | 7.733/7.733 khớp |
| Local Moran I tái tính từ NTL đã xuất | Sai khác tuyệt đối tối đa 0,00016805 |
| Benjamini–Hochberg ở α = 0,05, tính lại từ `lisa_p_sim` xuất | Khớp tuyệt đối, 2.880 ô |
| HH / LL từ BH trên p-value xuất | 370 / 2.510 ô |

Sai khác Local I không được diễn giải như sai số thuật toán: cột `ntl_mean` và `lisa_I` trong CSV đã được làm tròn, còn thuật toán gốc có dữ liệu trước khi làm tròn.

## Conditional permutation độc lập

- Mô hình: giữ focal cố định, lấy các phần tử khác **không hoàn lại** trong mỗi lần hoán vị, độ trễ không gian chuẩn hóa theo số láng giềng, Local Moran theo chuẩn ESDA. **999 permutations**, seed độc lập **20261111**.
- Quy tắc pseudo p-value: hai phía, lấy hai lần đuôi nhỏ hơn, cộng một, tie tolerance 1e-12; sau đó BH ở α = 0,05.
- Tương quan giữa p-value tái mô phỏng và CSV của app: **0,996736**.
- Mean absolute difference của p: **0,015636**; P95 absolute difference: **0,058**.
- Số ô BH significant: **2.879** (độc lập) so với **2.880** (app); **179 ô** khác quyết định BH theo seed này.

| Cụm | App | Độc lập | Giao | Hợp | Jaccard |
|---|---:|---:|---:|---:|---:|
| High–High | 370 | 375 | 360 | 385 | 0,9351 |
| Low–Low | 2.510 | 2.504 | 2.430 | 2.584 | 0,9404 |

Không nên coi 179 ô đổi quyết định là 179 lỗi: pseudop có sai số Monte Carlo, đặc biệt quanh ngưỡng FDR; dữ liệu NTL xuất ra cũng đã bị làm tròn. Để quy kết sai lệch, cần thêm các thử nghiệm thay seed và tăng số hoán vị. Những test deterministic đã tái lập đúng cấu trúc quan sát được.

## Giới hạn còn lại

1. Không có raster VIIRS gốc, vì thế **chưa** kiểm tra độc lập giá trị zonal/`exactextract` ở từng ô hoặc số tháng quan sát `cf_cvg`.
2. Không có bảng GHSL per-cell, vì thế **chưa** tính lại Spearman/AUC/bootstrap từ đầu; hình chụp màn hình là kết quả **trong app**.
3. Đây là phép triển khai lại phép tính từ CSV; **không phải** benchmark phần mềm ESDA trên toàn 8.333 ô trong phiên hiện tại.
4. Bản export không mang theo đầy đủ hyperparameters hay `lisa_method_version`; cấu hình được suy ra từ source code, p-value và kết quả xuất. Nên xuất thêm metadata vùng/cấu hình để audit được toàn bộ.

## File tái lập

- `validate_yanqing_lisa.py`: code độc lập, cần NumPy/Pandas, chạy cùng thư mục với CSV nguồn.
- `yanqing_lisa_independent_cell_comparison.csv`: so sánh từng `grid_id`.
- `yanqing_lisa_independent_summary.json`: thống kê máy đọc được.
- `validation_run_log.txt`: log chạy.

**Đánh giá:** Tầng statistical validation vượt qua các kiểm tra định lượng đầu tiên, với giới hạn Monte Carlo được nhận diện rõ. Tầng raster-extraction và external proxy vẫn cần dữ liệu cấp pixel hoặc GHSL per-cell độc lập.
