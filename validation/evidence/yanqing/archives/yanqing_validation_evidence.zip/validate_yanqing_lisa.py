"""Independent Yanqing 2020 Local Moran + BH-FDR reconstruction.
Run: python validate_yanqing_lisa.py
Requires: pandas, numpy. Reads CSV in same directory.
This independent Monte Carlo uses a separate seed; app pseudo-p is not expected to match exactly.
"""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'CHN_beijing_yanqing_2020_500m_lisa_cells.csv'
OUT = ROOT / 'yanqing_lisa_independent_cell_comparison.csv'
SUMMARY = ROOT / 'yanqing_lisa_independent_summary.json'
PERMS, SEED, ALPHA, SIZE = 999, 20261111, 0.05, 500

def bh(p, alpha=0.05):
    order = np.argsort(p)
    ranks = np.arange(1, len(p)+1)
    valid = np.where(p[order] <= alpha * ranks / len(p))[0]
    keep = valid[-1] + 1 if len(valid) else 0
    selected = np.zeros(len(p), bool)
    selected[order[:keep]] = True
    return selected

def main():
    d = pd.read_csv(SOURCE)
    x = d['ntl_mean'].to_numpy(float)
    area = d['area_km2'].to_numpy(float)
    cx = d['centroid_x_epsg32650'].to_numpy(float)
    cy = d['centroid_y_epsg32650'].to_numpy(float)
    n = len(d)
    edge = area < 0.99 * (SIZE/1000)**2
    active = (~edge) & np.isfinite(x) & (x > 0)
    pool = np.flatnonzero(active)
    m = len(pool)
    z = np.full(n, np.nan)
    z[active] = (x[active] - x[active].mean())/x[active].std(ddof=1)

    # Grid indices follow the published centroid-coordinate convention.
    ix = np.floor((cx+1e-6)/SIZE).astype(np.int64)
    iy = np.floor((cy+1e-6)/SIZE).astype(np.int64)
    ix = ix-ix.min()+1
    iy = iy-iy.min()+1
    h = int(iy.max())+3
    keys = ix*h+iy
    assert len(set(keys[pool])) == m, 'Duplicate active grid index'
    lookup = {int(keys[i]): int(i) for i in pool}
    directions = [(a,b) for a in (-1,0,1) for b in (-1,0,1) if (a,b)!=(0,0)]
    nbr = np.full((n,8), -1, dtype=np.int64)
    for i in pool:
        for j, (dx,dy) in enumerate(directions):
            nbr[i,j] = lookup.get(int(keys[i]+dx*h+dy), -1)
    k = np.count_nonzero(nbr>=0, axis=1)
    focal = active & (k>=1)
    fi = np.flatnonzero(focal)
    assert np.array_equal(pool, fi), 'Sample fixture has a focal without neighbors'

    m2 = np.sum(z[pool]**2)/(m-1)
    lag = np.full(n, np.nan)
    observed = np.full(n, np.nan)
    for i in fi:
        neighbors = nbr[i, nbr[i]>=0]
        lag[i] = z[neighbors].mean()
        observed[i] = z[i]*lag[i]/m2
    quadrant = np.full(n, '', dtype=object)
    for i in fi:
        if z[i]>0 and lag[i]>0: quadrant[i]='High-High'
        elif z[i]<0 and lag[i]<0: quadrant[i]='Low-Low'
        elif z[i]>0 and lag[i]<0: quadrant[i]='High-Low'
        elif z[i]<0 and lag[i]>0: quadrant[i]='Low-High'

    # Conditional draws: uniform *distinct* non-focal members per replicate.
    rng = np.random.default_rng(SEED)
    ge = np.zeros(len(fi), np.int32)
    le = np.zeros(len(fi), np.int32)
    K = k[fi]
    max_k = int(K.max())
    masks = np.arange(max_k)[None,:] < K[:,None]
    pos = np.searchsorted(pool, fi)
    for _ in range(PERMS):
        draws = np.empty((len(fi), max_k), np.int64)
        for slot in range(max_k):
            draws[:,slot] = rng.integers(0,m-1,size=len(fi))
            repeated = (draws[:,:slot] == draws[:,slot,None]).any(axis=1) if slot else np.zeros(len(fi),bool)
            while repeated.any():
                draws[repeated,slot] = rng.integers(0,m-1,size=int(repeated.sum()))
                repeated = (draws[:,:slot] == draws[:,slot,None]).any(axis=1)
        draws += draws>=pos[:,None]
        sim_lag = (z[pool[draws]]*masks).sum(axis=1)/K
        sim_I = z[fi]*sim_lag/m2
        ge += sim_I>=observed[fi]-1e-12
        le += sim_I<=observed[fi]+1e-12
    p = np.full(n,np.nan)
    p[fi] = np.minimum(1,2*(np.minimum(ge,le)+1)/(PERMS+1))
    sig = np.zeros(n,bool)
    sig[fi] = bh(p[fi],ALPHA)
    app_sig = d['lisa_significant'].astype(bool).to_numpy()
    app_p = d['lisa_p_sim'].to_numpy(float)
    app_q = d['lisa_quadrant_raw'].fillna('').to_numpy(str)
    app_I = d['lisa_I'].to_numpy(float)
    independent_class = np.where(edge, 'Edge-Masked', np.where(sig, quadrant, 'Not Significant'))
    results = pd.DataFrame({
        'grid_id':d.grid_id, 'ntl_mean_export_rounded':x,
        'active_lisa':focal.astype(int),'queen_neighbors_reconstructed':k,
        'local_I_recomputed_from_rounded_ntl':observed,
        'local_I_exported':app_I,
        'raw_quadrant_recomputed':quadrant,
        'raw_quadrant_exported':app_q,
        'p_independent_seed_20261111':p,
        'p_exported':app_p,
        'bh_independent':sig.astype(int),
        'bh_exported':app_sig.astype(int),
        'class_independent':independent_class,
        'class_exported':d.lisa_class
    })
    results.to_csv(OUT,index=False)
    valid = np.isfinite(p) & np.isfinite(app_p)
    pdiff=np.abs(p[valid]-app_p[valid])
    exact_I_diff = np.abs(observed[valid]-app_I[valid])
    counts={}
    for label in ['High-High','Low-Low']:
        a=sig&(quadrant==label)
        b=app_sig&(app_q==label)
        counts[label]={'recomputed':int(a.sum()),'exported':int(b.sum()),'intersection':int((a&b).sum()),'union':int((a|b).sum()),'jaccard':float((a&b).sum()/(a|b).sum())}
    app_bh = np.zeros(n,bool)
    app_bh[fi] = bh(app_p[fi], ALPHA)
    summary={
       'source_file':SOURCE.name,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
       'rows':n,'edge':int(edge.sum()),'lisa_focal':len(fi),
       'edge_exact_match':bool(np.array_equal(edge,d.is_edge_masked.astype(bool).to_numpy())),
       'neighbor_counts_exact_match':bool(np.array_equal(k,d.lisa_n_neighbors.to_numpy())),
       'raw_quadrant_exact_match':bool(np.array_equal(quadrant[fi],app_q[fi])),
       'local_I_max_abs_diff_from_rounded_input':float(exact_I_diff.max()),
       'bh_recomputed_from_exported_p_exact_match':bool(np.array_equal(app_bh,app_sig)),
       'monte_carlo_perms':PERMS,'independent_seed':SEED,
       'monte_carlo_p_correlation':float(np.corrcoef(p[valid],app_p[valid])[0,1]),
       'monte_carlo_p_mean_absolute_difference':float(pdiff.mean()),
       'monte_carlo_p_p95_absolute_difference':float(np.quantile(pdiff,.95)),
       'bh_independent':int(sig.sum()),'bh_exported':int(app_sig.sum()),
       'bh_disagree':int((sig!=app_sig).sum()),'clusters':counts,
       'notes':['Exported ntl_mean is rounded, so Local I cannot be bitwise identical.',
                'Monte Carlo runs use different seeds; p-value decisions may differ near FDR threshold.',
                'Independent estimator implements specified without-replacement conditional null; not an ESDA executable comparison.',
                'No raw VIIRS or GHSL raster supplied, so satellite extraction and external proxy correlations were not independently validated.']}
    SUMMARY.write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
